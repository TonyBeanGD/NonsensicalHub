Credits
=======
  
  - Showdown v2
    * [Estevão Santos](https://github.com/tivie)

  - Showdown v1
    * [Estevão Santos](https://github.com/tivie)
    * [Pascal Deschênes](https://github.com/pdeschen)

  - Showdown v0
    * [Corey Innis](http://github.com/coreyti):<br/>
      Original GitHub project maintainer
    * [Remy Sharp](https://github.com/remy/):<br/>
      CommonJS-compatibility and more
    * [Konstantin Käfer](https://github.com/kkaefer/):<br/>
      CommonJS packaging
    * [Roger Braun](https://github.com/rogerbraun):<br/>
      Github-style code blocks
    * [Dominic Tarr](https://github.com/dominictarr):<br/>
      Documentation
    * [Cat Chen](https://github.com/CatChen):<br/>
      Export fix
    * [Titus Stone](https://github.com/tstone):<br/>
      Mocha tests, extension mechanism, and bug fixes
    * [Rob Sutherland](https://github.com/roberocity):<br/>
      The idea that lead to extensions
    * [Pavel Lang](https://github.com/langpavel):<br/>
      Code cleanup
    * [Ben Combee](https://github.com/unwiredben):<br/>
      Regex optimization
    * [Adam Backstrom](https://github.com/abackstrom):<br/>
      WebKit bugfix
    * [Pascal Deschênes](https://github.com/pdeschen):<br/>
      Grunt support, extension fixes + additions, packaging improvements, documentation
    * [Estevão Santos](https://github.com/tivie)<br/>
      Bug fixing and late maintainer
    * [Hannah Wolfe](https://github.com/ErisDS)<br/>
      Bug fixes
    * [Alexandre Courtiol](https://github.com/acourtiol)<br/>
      Bug fixes and build optimization
    * [Karthik Balakrishnan](https://github.com/torcellite)<br/>
      Support for table alignment
    * [rheber](https://github.com/rheber)<br/>
      Cli
      

  - Original Project
    * [John Gruber](http://daringfireball.net/projects/markdown/)<br/>
      Author of Markdown
    * [John Fraser](http://attacklab.net/)<br/>
      Author of Showdown
