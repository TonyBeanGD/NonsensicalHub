﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luck_Draw
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 0;
            bool right = false;

            Console.WriteLine("请输入总共参加抽奖的人数");
            do
            {
                right = int.TryParse(Console.ReadLine(), out num);
                if (!right)
                {
                    Console.WriteLine("请输入正确的值");
                }
            }
            while (!right);
            Drawing<string> luckerList = new Drawing<string>(num);
            for (int i = 1; i <= num; i++)
            {
                Console.WriteLine("请输入第" + i + "个人的名字");
                luckerList.Join(Console.ReadLine());
            }
            luckerList.Show();
            Console.WriteLine("中奖者为" + luckerList.Draw());
            Console.Read();
            int num2 = 0;
            bool right2 = false;
            int num3 = 0;

            Console.WriteLine("请输入总共参加抽奖的人数2");
            do
            {
                right2 = int.TryParse(Console.ReadLine(), out num2);
                if (!right2)
                {
                    Console.WriteLine("请输入正确的值");
                }
            }
            while (!right2);
            Drawing<int> luckerList2 = new Drawing<int>(num2);
            for (int i = 1; i <= num2; i++)
            {
                do
                {
                    Console.WriteLine("请输入第" + i + "个人的学号");
                    right2 = int.TryParse(Console.ReadLine(), out num3);
                    if (!right2)
                    {
                        Console.WriteLine("请输入正确的值");
                    }
                }
                while (!right2);
                luckerList2.Join(num3);
            }
            luckerList2.Show();
            Console.WriteLine("中奖者为"+luckerList2.Draw());
            Console.Read();
        }
    }
}
