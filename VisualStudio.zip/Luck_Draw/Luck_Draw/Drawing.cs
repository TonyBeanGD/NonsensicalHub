﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Luck_Draw
{
    class Drawing<_Type>
    {
        int count = 0;
        _Type[] luckerList;
        public Drawing(int _num)
        {
            luckerList = new _Type[_num];
        }
        public void Join(_Type _current_lucker)
        {
            luckerList[count++] = _current_lucker;
        }
        public void Show()
        {
            for (int i = 0; i < luckerList.Length; i++)
            {
                Console.WriteLine("第" + (i + 1) + "个抽奖者是：" + luckerList[i]);
            }
        }
        public _Type Draw()
        {
            Random r = new Random();
            int i = r.Next(0, count);
            return luckerList[i];
        }
    }
}
