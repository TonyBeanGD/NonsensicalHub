﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nonsensical
{
    public class Nonsensical_Game
    {
        public enum Nonsencial
        {
            Arena,
            Bored_Card,
            Farm,
            Life,
            Nonsensical,
            Survival,
            War,
        }
    }
}
