﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System;

public class LoadingEffectManager : MonoBehaviour
{    
    #region AUTO_NodeBuilderVariable

    [SerializeField]
    private GameObject InputField;
    [SerializeField]
    private GameObject Placeholder;
    [SerializeField]
    private GameObject Text;

    #endregion AUTO_NodeBuilderVariable

    #region AUTO_NodeBuilderAttributes


    #endregion AUTO_NodeBuilderAttributes

    private void OnAwake()
    {
        #region AUTO_NodeBuilderAwake


    #endregion AUTO_NodeBuilderAwake
    }
}
